import React from 'react'
import RegisterForm from '@/components/RegisterForm'

const register = () => {
  return (
    <RegisterForm/>
  )
}

export default register